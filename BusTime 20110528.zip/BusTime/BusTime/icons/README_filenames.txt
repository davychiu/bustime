File naming convention:

cloudy.gif  		- Cloudy
nt_partlycloudy.gif	- Night Partly Cloudy
partlycloudy.gif	- Partly Cloudy
partlysunny.gif		- Partly Sunny
rain.gif		- Rain
tstorms.gif		- Thunderstorms
sunny.gif		- Sunny
snow.gif		- Snow
flurries.gif		- Flurries
Unknown.gif		- Unknown
chancesnow.gif       	- Chance of Snow
nt_snow.gif		- Night Snow
chancetstorms.gif	- Chance of Thunderstorms
freezerain.gif		- Freezing Rain
fog.gif			- Fog
chancerain.gif		- Chance of Rain
chancefreezerain.gif	- Chance of Freezing Rain
haze.gif		- Haze
overcast.gif		- Overcast


Not Complete 2-21-99 Eric Mindte