﻿namespace BusTime
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.MainMenu mainMenu1;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.mainMenu1 = new System.Windows.Forms.MainMenu();
            this.menuItem1 = new System.Windows.Forms.MenuItem();
            this.menuItem2 = new System.Windows.Forms.MenuItem();
            this.label1 = new System.Windows.Forms.Label();
            this.timer1 = new System.Windows.Forms.Timer();
            this.TimeLabel = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.foreIcon0 = new System.Windows.Forms.PictureBox();
            this.foreDay0 = new System.Windows.Forms.Label();
            this.foreHigh0 = new System.Windows.Forms.Label();
            this.foreLow0 = new System.Windows.Forms.Label();
            this.foreIcon1 = new System.Windows.Forms.PictureBox();
            this.foreDay1 = new System.Windows.Forms.Label();
            this.foreHigh1 = new System.Windows.Forms.Label();
            this.foreLow1 = new System.Windows.Forms.Label();
            this.foreIcon2 = new System.Windows.Forms.PictureBox();
            this.foreDay2 = new System.Windows.Forms.Label();
            this.foreHigh2 = new System.Windows.Forms.Label();
            this.foreLow2 = new System.Windows.Forms.Label();
            this.foreIcon3 = new System.Windows.Forms.PictureBox();
            this.foreDay3 = new System.Windows.Forms.Label();
            this.foreHigh3 = new System.Windows.Forms.Label();
            this.foreLow3 = new System.Windows.Forms.Label();
            this.foreIcon4 = new System.Windows.Forms.PictureBox();
            this.foreDay4 = new System.Windows.Forms.Label();
            this.foreHigh4 = new System.Windows.Forms.Label();
            this.foreLow4 = new System.Windows.Forms.Label();
            this.progressBar1 = new System.Windows.Forms.ProgressBar();
            this.SuspendLayout();
            // 
            // mainMenu1
            // 
            this.mainMenu1.MenuItems.Add(this.menuItem1);
            this.mainMenu1.MenuItems.Add(this.menuItem2);
            // 
            // menuItem1
            // 
            this.menuItem1.Text = "Quit";
            this.menuItem1.Click += new System.EventHandler(this.menuItem1_Click);
            // 
            // menuItem2
            // 
            this.menuItem2.Text = "Refresh";
            this.menuItem2.Click += new System.EventHandler(this.menuItem2_Click);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Underline);
            this.label1.Location = new System.Drawing.Point(3, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(237, 20);
            this.label1.Text = "WB 025 E22 AV @ RUPERT";
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // TimeLabel
            // 
            this.TimeLabel.Font = new System.Drawing.Font("Tahoma", 14F, System.Drawing.FontStyle.Regular);
            this.TimeLabel.Location = new System.Drawing.Point(125, 0);
            this.TimeLabel.Name = "TimeLabel";
            this.TimeLabel.Size = new System.Drawing.Size(115, 26);
            this.TimeLabel.Text = "00:00:00 PM";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.label2.Location = new System.Drawing.Point(14, 52);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(297, 20);
            this.label2.Text = "no times available";
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Underline);
            this.label3.Location = new System.Drawing.Point(3, 72);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(238, 20);
            this.label3.Text = "SB 027 E20 AV @ RUPERT ST";
            // 
            // label4
            // 
            this.label4.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label4.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.label4.Location = new System.Drawing.Point(14, 92);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(297, 20);
            this.label4.Text = "no times available";
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Underline);
            this.label5.Location = new System.Drawing.Point(3, 112);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(237, 20);
            this.label5.Text = "NB 027 RUPERT ST @ SEAFORTH DR";
            // 
            // label6
            // 
            this.label6.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label6.Font = new System.Drawing.Font("Tahoma", 11F, System.Drawing.FontStyle.Regular);
            this.label6.Location = new System.Drawing.Point(14, 132);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(297, 20);
            this.label6.Text = "no times available";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Anchor = System.Windows.Forms.AnchorStyles.None;
            this.pictureBox1.Location = new System.Drawing.Point(30, 166);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(50, 42);
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label7.Location = new System.Drawing.Point(86, 166);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(142, 16);
            this.label7.Text = "label7";
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Tahoma", 8F, System.Drawing.FontStyle.Regular);
            this.label8.Location = new System.Drawing.Point(86, 182);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(109, 16);
            this.label8.Text = "label8";
            // 
            // foreIcon0
            // 
            this.foreIcon0.Location = new System.Drawing.Point(6, 232);
            this.foreIcon0.Name = "foreIcon0";
            this.foreIcon0.Size = new System.Drawing.Size(40, 32);
            this.foreIcon0.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // foreDay0
            // 
            this.foreDay0.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreDay0.Location = new System.Drawing.Point(6, 217);
            this.foreDay0.Name = "foreDay0";
            this.foreDay0.Size = new System.Drawing.Size(51, 12);
            this.foreDay0.Text = "label9";
            // 
            // foreHigh0
            // 
            this.foreHigh0.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreHigh0.Location = new System.Drawing.Point(6, 267);
            this.foreHigh0.Name = "foreHigh0";
            this.foreHigh0.Size = new System.Drawing.Size(51, 12);
            this.foreHigh0.Text = "label10";
            // 
            // foreLow0
            // 
            this.foreLow0.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreLow0.Location = new System.Drawing.Point(6, 279);
            this.foreLow0.Name = "foreLow0";
            this.foreLow0.Size = new System.Drawing.Size(51, 12);
            this.foreLow0.Text = "label11";
            // 
            // foreIcon1
            // 
            this.foreIcon1.Location = new System.Drawing.Point(52, 232);
            this.foreIcon1.Name = "foreIcon1";
            this.foreIcon1.Size = new System.Drawing.Size(40, 32);
            this.foreIcon1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // foreDay1
            // 
            this.foreDay1.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreDay1.Location = new System.Drawing.Point(52, 217);
            this.foreDay1.Name = "foreDay1";
            this.foreDay1.Size = new System.Drawing.Size(51, 12);
            this.foreDay1.Text = "label9";
            // 
            // foreHigh1
            // 
            this.foreHigh1.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreHigh1.Location = new System.Drawing.Point(52, 267);
            this.foreHigh1.Name = "foreHigh1";
            this.foreHigh1.Size = new System.Drawing.Size(51, 12);
            this.foreHigh1.Text = "label10";
            // 
            // foreLow1
            // 
            this.foreLow1.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreLow1.Location = new System.Drawing.Point(52, 279);
            this.foreLow1.Name = "foreLow1";
            this.foreLow1.Size = new System.Drawing.Size(51, 12);
            this.foreLow1.Text = "label11";
            // 
            // foreIcon2
            // 
            this.foreIcon2.Location = new System.Drawing.Point(98, 232);
            this.foreIcon2.Name = "foreIcon2";
            this.foreIcon2.Size = new System.Drawing.Size(40, 32);
            this.foreIcon2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // foreDay2
            // 
            this.foreDay2.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreDay2.Location = new System.Drawing.Point(98, 217);
            this.foreDay2.Name = "foreDay2";
            this.foreDay2.Size = new System.Drawing.Size(51, 12);
            this.foreDay2.Text = "label9";
            // 
            // foreHigh2
            // 
            this.foreHigh2.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreHigh2.Location = new System.Drawing.Point(98, 267);
            this.foreHigh2.Name = "foreHigh2";
            this.foreHigh2.Size = new System.Drawing.Size(51, 12);
            this.foreHigh2.Text = "label10";
            // 
            // foreLow2
            // 
            this.foreLow2.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreLow2.Location = new System.Drawing.Point(98, 279);
            this.foreLow2.Name = "foreLow2";
            this.foreLow2.Size = new System.Drawing.Size(51, 12);
            this.foreLow2.Text = "label11";
            // 
            // foreIcon3
            // 
            this.foreIcon3.Location = new System.Drawing.Point(144, 232);
            this.foreIcon3.Name = "foreIcon3";
            this.foreIcon3.Size = new System.Drawing.Size(40, 32);
            this.foreIcon3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // foreDay3
            // 
            this.foreDay3.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreDay3.Location = new System.Drawing.Point(144, 217);
            this.foreDay3.Name = "foreDay3";
            this.foreDay3.Size = new System.Drawing.Size(51, 12);
            this.foreDay3.Text = "label9";
            // 
            // foreHigh3
            // 
            this.foreHigh3.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreHigh3.Location = new System.Drawing.Point(144, 267);
            this.foreHigh3.Name = "foreHigh3";
            this.foreHigh3.Size = new System.Drawing.Size(51, 12);
            this.foreHigh3.Text = "label10";
            // 
            // foreLow3
            // 
            this.foreLow3.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreLow3.Location = new System.Drawing.Point(144, 279);
            this.foreLow3.Name = "foreLow3";
            this.foreLow3.Size = new System.Drawing.Size(51, 12);
            this.foreLow3.Text = "label11";
            // 
            // foreIcon4
            // 
            this.foreIcon4.Location = new System.Drawing.Point(190, 232);
            this.foreIcon4.Name = "foreIcon4";
            this.foreIcon4.Size = new System.Drawing.Size(40, 32);
            this.foreIcon4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            // 
            // foreDay4
            // 
            this.foreDay4.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreDay4.Location = new System.Drawing.Point(190, 217);
            this.foreDay4.Name = "foreDay4";
            this.foreDay4.Size = new System.Drawing.Size(51, 12);
            this.foreDay4.Text = "label9";
            // 
            // foreHigh4
            // 
            this.foreHigh4.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreHigh4.Location = new System.Drawing.Point(190, 267);
            this.foreHigh4.Name = "foreHigh4";
            this.foreHigh4.Size = new System.Drawing.Size(51, 12);
            this.foreHigh4.Text = "label10";
            // 
            // foreLow4
            // 
            this.foreLow4.Font = new System.Drawing.Font("Tahoma", 7F, System.Drawing.FontStyle.Regular);
            this.foreLow4.Location = new System.Drawing.Point(190, 279);
            this.foreLow4.Name = "foreLow4";
            this.foreLow4.Size = new System.Drawing.Size(51, 12);
            this.foreLow4.Text = "label11";
            // 
            // progressBar1
            // 
            this.progressBar1.Location = new System.Drawing.Point(0, 0);
            this.progressBar1.Maximum = 80;
            this.progressBar1.Name = "progressBar1";
            this.progressBar1.Size = new System.Drawing.Size(70, 13);
            this.progressBar1.Visible = false;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(96F, 96F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(240, 294);
            this.Controls.Add(this.progressBar1);
            this.Controls.Add(this.foreLow4);
            this.Controls.Add(this.foreLow3);
            this.Controls.Add(this.foreLow2);
            this.Controls.Add(this.foreLow1);
            this.Controls.Add(this.foreLow0);
            this.Controls.Add(this.foreHigh4);
            this.Controls.Add(this.foreHigh3);
            this.Controls.Add(this.foreHigh2);
            this.Controls.Add(this.foreHigh1);
            this.Controls.Add(this.foreHigh0);
            this.Controls.Add(this.foreDay4);
            this.Controls.Add(this.foreDay3);
            this.Controls.Add(this.foreDay2);
            this.Controls.Add(this.foreDay1);
            this.Controls.Add(this.foreDay0);
            this.Controls.Add(this.foreIcon4);
            this.Controls.Add(this.foreIcon3);
            this.Controls.Add(this.foreIcon2);
            this.Controls.Add(this.foreIcon1);
            this.Controls.Add(this.foreIcon0);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.TimeLabel);
            this.Controls.Add(this.label1);
            this.Location = new System.Drawing.Point(0, 0);
            this.Menu = this.mainMenu1;
            this.Name = "MainForm";
            this.Text = "Bus Timetable";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.MenuItem menuItem1;
        private System.Windows.Forms.Label TimeLabel;
        private System.Windows.Forms.MenuItem menuItem2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.PictureBox foreIcon0;
        private System.Windows.Forms.Label foreDay0;
        private System.Windows.Forms.Label foreHigh0;
        private System.Windows.Forms.Label foreLow0;
        private System.Windows.Forms.PictureBox foreIcon1;
        private System.Windows.Forms.Label foreDay1;
        private System.Windows.Forms.Label foreHigh1;
        private System.Windows.Forms.Label foreLow1;
        private System.Windows.Forms.PictureBox foreIcon2;
        private System.Windows.Forms.Label foreDay2;
        private System.Windows.Forms.Label foreHigh2;
        private System.Windows.Forms.Label foreLow2;
        private System.Windows.Forms.PictureBox foreIcon3;
        private System.Windows.Forms.Label foreDay3;
        private System.Windows.Forms.Label foreHigh3;
        private System.Windows.Forms.Label foreLow3;
        private System.Windows.Forms.PictureBox foreIcon4;
        private System.Windows.Forms.Label foreDay4;
        private System.Windows.Forms.Label foreHigh4;
        private System.Windows.Forms.Label foreLow4;
        private System.Windows.Forms.ProgressBar progressBar1;

    }
}

